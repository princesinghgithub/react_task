import React from 'react'

function Navbar() {
  return (
    <div>
     
<nav className="navbar  bg-dark nav_1">
  <a class="navbar-brand" href="#">
    To-do List
  </a>
</nav>
    </div>
  )
}

export default Navbar